<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Loan extends Admin_Controller {

    function __construct()
    {
       parent::__construct();
       $this->load->model('loan_model');
    }

    function index(){
      $data['page_title'] = "Loan Management";
      $data['page_header'] = "Loan Management";
      $content['lists'] = $this->loan_model->list();
      $data['content'] = $this->load->view('admin/loan/index',$content, TRUE);
      $this->load->view($this->template,$data);
    }

    function create(){
      if($this->input->post('create_loan'))
      {
         $this->loan_model->create(array(
           'user_id' => $this->input->post('user'),
           'loan_amount' => $this->input->post('loan_amount'),
           'interest' => $this->input->post('interest'),
           'time' => $this->input->post('time_period'),
           'created' => date('d-m-Y h:i:s'),
           'updated' => date('d-m-Y h:i:s'),
           'status' => $this->input->post('status')
         ));
         $this->session->set_flashdata('alert','<div class="alert alert-success">Loan Created Successfully</div>');
      }
      $data['page_title'] = "Loan Management";
      $data['page_header'] = "Create Loan";
      $content['content'] = $this->loan_model->userList();
      $data['content'] = $this->load->view('admin/loan/create',$content , TRUE);
      $this->load->view($this->template,$data);
    }

    function update(){
      if($this->input->post('update_loan'))
      {
         $this->loan_model->update($this->uri->segment(4),array(
           'user_id'     => $this->input->post('user'),
           'loan_amount' => $this->input->post('loan_amount'),
           'interest'    => $this->input->post('interest'),
           'time'        => $this->input->post('time_period'),
           'updated'     => date('d-m-Y h:i:s'),
           'status'      => $this->input->post('status')
         ));
         $this->session->set_flashdata('alert','<div class="alert alert-success">Loan Updated Successfully</div>');
      }
      $data['page_title'] = "Loan Management";
      $data['page_header'] = "Update Loan";
      $content['userList'] = $this->loan_model->userList();
      $content['loanDetail'] = $this->loan_model->loanDetail($this->uri->segment(4));
      $data['content'] = $this->load->view('admin/loan/update',$content,TRUE);
      $this->load->view($this->template,$data);
    }

    function delete(){
        $this->loan_model->delete($this->uri->segment(4));
        redirect('admin/loan');  
    }

  }
?>
