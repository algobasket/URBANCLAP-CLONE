<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<div class="header-bg">
			<div class="container">
				<div class="row">
					<div class="col-md-9 col-sm-6 col-xs-7">
						<h3><?php echo lang('core menu privacy'); ?></h3>
					</div>
				</div>
			</div>
</div>

<div class="container theme-showcase" role="main">
	
	<div class="row">
		<div class="col-md-12">
			<?php echo lang('core content demo'); ?>
			<div style="margin-bottom:400px">
				
			</div>
		</div>
	</div>
	
</div>